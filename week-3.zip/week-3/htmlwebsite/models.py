from django.db import models

# Create your models here.
class Contact(models.Model):
    sno = models.AutoField(primary_key=True)
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    address=models.CharField(max_length=100)
class VoterDetails(models.Model):
    Vid = models.AutoField(primary_key=True)
    name=models.CharField(max_length=100)
    age=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    address=models.CharField(max_length=100)
class CandidateDetails(models.Model):
    Canid = models.CharField(primary_key=True,max_length=100)
    candidate_name=models.CharField(max_length=100)
    age=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    address=models.CharField(max_length=100)
class Party(models.Model):
    party_id = models.CharField(primary_key=True,max_length=100)
    can_id=models.CharField(max_length=100)
    party_name=models.CharField(max_length=100)
    party_symbol=models.CharField(max_length=100)

