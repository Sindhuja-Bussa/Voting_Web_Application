from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def home(request):
    #return HttpResponse("Iam Website")
    return render(request,'vote.html')
def signup(request):
    return render(request,'signup.html')
def login(request):
    return render(request,'login.html')
def contact(request):
    return render(request,'contact.html')
    